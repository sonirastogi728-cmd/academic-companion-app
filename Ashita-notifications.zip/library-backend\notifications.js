const { execFile } = require("child_process");
const path = require("path");

const CPP_DIR = path.join(__dirname, "cpp");
const EXE = path.join(CPP_DIR, "notifications.exe");

function runCpp(args, cb) {
  execFile(EXE, args.map(String), { cwd: CPP_DIR }, (err, stdout) => {
    try { cb(null, JSON.parse(stdout)); }
    catch { cb(new Error("Notification program failed. Is notifications.exe built?")); }
  });
}

module.exports = function (app, auth, db, canEdit) {
  const findSubject = (id) => db.subjects.find((s) => String(s.id) === String(id));
  const nameOf = (id) => { const s = findSubject(id); return s ? s.name : id; };
  const fail = (res, err) => res.status(500).json({ message: err.message });
  const withNames = (list) => list.map((n) => ({ ...n, subjectName: nameOf(n.subjectId) }));

  // subjects this person gets notifications for
  const mySubjectIds = (user) =>
    user.role === "faculty"
      ? db.subjects.filter((s) => canEdit(user, s)).map((s) => s.id)
      : db.enrollments.filter((e) => e.studentId === user.id).map((e) => e.subjectId);

  // Faculty: see the detected category before posting
  app.post("/api/notifications/preview", auth, (req, res) => {
    if (req.user.role !== "faculty") return res.status(403).json({ message: "Faculty only" });
    const title = String(req.body.title || "");
    const message = String(req.body.message || "") || " ";
    runCpp(["classify", title, message], (err, data) => (err ? fail(res, err) : res.json(data)));
  });

  // Faculty: post a notification
  app.post("/api/notifications", auth, (req, res) => {
    const sub = findSubject(req.body.subjectId);
    if (!sub) return res.status(404).json({ message: "Subject not found" });
    if (!canEdit(req.user, sub)) return res.status(403).json({ message: "Not your subject" });

    const title = String(req.body.title || "").trim();
    const message = String(req.body.message || "").trim() || " ";
    if (!title) return res.status(400).json({ message: "Title is required" });
    if (title.length > 120 || message.length > 500)
      return res.status(400).json({ message: "Title max 120, message max 500 characters" });

    runCpp(["add", sub.id, req.user.id, title, message], (err, data) => {
      if (err) return fail(res, err);
      res.status(data.ok ? 200 : 400).json(data);
    });
  });

  // Student (and faculty): top 3 across my subjects, the rest are hidden
  app.get("/api/notifications/top", auth, (req, res) => {
    const ids = mySubjectIds(req.user);
    if (ids.length === 0) return res.json({ shown: [], hidden: 0, total: 0 });
    runCpp(["top", 3, ...ids], (err, data) =>
      err ? fail(res, err) : res.json({ ...data, shown: withNames(data.shown) }));
  });

  // Faculty: everything in my subject, in priority order
  app.get("/api/notifications/subject/:subjectId", auth, (req, res) => {
    const sub = findSubject(req.params.subjectId);
    if (!sub || !canEdit(req.user, sub)) return res.status(403).json({ message: "Not allowed" });
    runCpp(["subject", sub.id], (err, data) =>
      err ? fail(res, err) : res.json({ notifications: withNames(data.notifications) }));
  });

  // Faculty: delete my own notification
  app.delete("/api/notifications/:id", auth, (req, res) => {
    if (req.user.role !== "faculty") return res.status(403).json({ message: "Faculty only" });
    if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ message: "Bad id" });
    runCpp(["delete", req.params.id, req.user.id], (err, data) => {
      if (err) return fail(res, err);
      res.status(data.ok ? 200 : 403).json(data);
    });
  });
};