import { useState, useEffect } from "react";
import {
  getSubjects,
  postNotification,
  getTopNotifications,
  getSubjectNotifications,
  deleteNotification,
} from "../data/api";

// keyword, category (same words the C++ engine understands)
const KEYWORDS = [
  ["exam", "Exam"], ["midsem", "Exam"], ["endsem", "Exam"], ["viva", "Exam"],
  ["datesheet", "Exam"], ["admit card", "Exam"],
  ["rescheduled", "Class Rescheduling"], ["postponed", "Class Rescheduling"],
  ["timetable", "Class Rescheduling"], ["class cancelled", "Class Rescheduling"],
  ["quiz", "Quiz"], ["unit test", "Quiz"], ["test", "Quiz"],
  ["holiday", "Holiday"], ["vacation", "Holiday"],
  ["internship", "Internship"], ["placement", "Internship"], ["campus drive", "Internship"],
  ["enrollment", "Enrollment"], ["registration", "Enrollment"], ["admission", "Enrollment"],
  ["assignment", "Assignment"], ["submission", "Assignment"], ["deadline", "Assignment"],
  ["homework", "Homework"], ["worksheet", "Homework"],
  ["event", "Event Participation"], ["workshop", "Event Participation"],
  ["hackathon", "Event Participation"], ["competition", "Event Participation"],
  ["donation", "Donation"], ["charity", "Donation"],
  ["bus", "Bus Scheduling"], ["transport", "Bus Scheduling"],
];

function NotificationCard({ n, onDelete }) {
  return (
    <div className="card">
      <div className="row between">
        <strong>{n.title}</strong>
        <span className="badge">{n.category}</span>
      </div>
      {n.message.trim() && <p>{n.message}</p>}
      <small className="muted">
        {n.subjectName} · {new Date(n.time * 1000).toLocaleString()}
      </small>
      {onDelete && (
        <div>
          <button className="danger" onClick={() => onDelete(n.id)}>Delete</button>
        </div>
      )}
    </div>
  );
}

function FacultyView() {
  const [subjects, setSubjects] = useState([]);
  const [subjectId, setSubjectId] = useState("");
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [list, setList] = useState([]);
  const [note, setNote] = useState("");

  useEffect(() => {
    getSubjects("mine").then((r) => r.ok && setSubjects(r.subjects));
  }, []);

  async function loadList(id) {
    if (!id) return setList([]);
    const r = await getSubjectNotifications(id);
    if (r.ok) setList(r.notifications);
  }

  function pickSubject(id) {
    setSubjectId(id);
    setNote("");
    loadList(id);
  }

  async function handlePost(e) {
    e.preventDefault();
    if (!subjectId) return setNote("Select a subject first.");
    const r = await postNotification(subjectId, title, message);
    if (r.ok) {
      setNote(`Posted as ${r.category} (priority ${r.score}).`);
      setTitle("");
      setMessage("");
      loadList(subjectId);
    } else {
      setNote(r.message || "Could not post.");
    }
  }

  async function handleDelete(id) {
    if (!window.confirm("Delete this notification?")) return;
    const r = await deleteNotification(id);
    setNote(r.ok ? "Deleted." : r.message || "Could not delete.");
    loadList(subjectId);
  }

  return (
    <>
      <form onSubmit={handlePost}>
        <div className="row">
          <select value={subjectId} onChange={(e) => pickSubject(e.target.value)}>
            <option value="">Select subject</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
        <div className="row">
          <input
            list="keyword-list"
            placeholder="Title: click and pick a keyword (e.g. exam), then add details"
            value={title}
            maxLength={120}
            onChange={(e) => setTitle(e.target.value)}
          />
          <datalist id="keyword-list">
            {KEYWORDS.map(([k, cat]) => (
              <option key={k} value={k} label={cat} />
            ))}
          </datalist>
        </div>
        <div className="row">
          <input placeholder="Message" value={message}
            maxLength={500} onChange={(e) => setMessage(e.target.value)} />
        </div>
        <button type="submit">Post notification</button>
      </form>

      {note && <p className="message">{note}</p>}

      {subjectId && (
        <>
          <h4>Posted for this subject (highest priority first)</h4>
          {list.length === 0 && <p className="muted">Nothing posted yet.</p>}
          {list.map((n) => (
            <NotificationCard key={n.id} n={n} onDelete={handleDelete} />
          ))}
        </>
      )}
    </>
  );
}

function StudentView() {
  const [list, setList] = useState(null);

  useEffect(() => {
    getTopNotifications(true).then((r) => r.ok && setList(r.shown));
  }, []);

  if (!list) return <p className="muted">Loading...</p>;
  if (list.length === 0) return <p className="muted">No notifications yet.</p>;

  const top = list.slice(0, 3);
  const rest = list.slice(3);
  return (
    <>
      {top.map((n) => <NotificationCard key={n.id} n={n} />)}
      {rest.length > 0 && (
        <details>
          <summary>
            + {rest.length} more notification{rest.length > 1 ? "s" : ""} (click to show)
          </summary>
          {rest.map((n) => <NotificationCard key={n.id} n={n} />)}
        </details>
      )}
    </>
  );
}

export default function NotificationsPage({ user, onBack }) {
  return (
    <div className="card">
      <button onClick={onBack}>← Back</button>
      <h3>{user.role === "faculty" ? "Post notifications" : "Top priority notifications"}</h3>
      {user.role === "faculty" ? <FacultyView /> : <StudentView />}
    </div>
  );
}