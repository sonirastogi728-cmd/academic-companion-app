#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <ctime>
#include <cctype>
using namespace std;

struct Notification {
    int id;
    string subjectId, facultyId;
    long long time;
    string category;
    int score;
    string title, message;
};

struct CategoryDef {
    string name;
    int score;               // higher = more important
    vector<string> phrases;  // whole words or phrases
    vector<string> stems;    // word beginnings: "reschedul" matches "rescheduled"
};

// ---------- helpers ----------
string clean(string s) {
    for (auto &c : s)
        if (c == '|') c = '/';
        else if (c == '\n' || c == '\r') c = ' ';
    return s;
}

string jsonEscape(const string &s) {
    string o;
    for (char c : s) {
        if (c == '"') o += "\\\"";
        else if (c == '\\') o += "\\\\";
        else if ((unsigned char)c < 32) o += ' ';
        else o += c;
    }
    return o;
}

// "Mid-Sem EXAM on 12th" -> {"mid","sem","exam","on","12th"}
vector<string> tokenize(const string &text) {
    vector<string> words;
    string cur;
    for (char ch : text) {
        if (isalnum((unsigned char)ch)) cur += (char)tolower((unsigned char)ch);
        else if (!cur.empty()) { words.push_back(cur); cur.clear(); }
    }
    if (!cur.empty()) words.push_back(cur);
    return words;
}

// all runs of 1..maxN consecutive words: {"mid","mid sem","mid sem exam","sem",...}
vector<string> makeNgrams(const vector<string> &tokens, int maxN) {
    vector<string> out;
    for (size_t i = 0; i < tokens.size(); i++) {
        string phrase;
        for (int len = 1; len <= maxN && i + len <= tokens.size(); len++) {
            if (len > 1) phrase += ' ';
            phrase += tokens[i + len - 1];
            out.push_back(phrase);
        }
    }
    return out;
}

// ---------- DS 1: Trie (prefix tree) for word stems ----------
class Trie {
    struct Node {
        Node *next[26] = {};
        int category = -1; // >= 0 means a stem ends here
    };
    Node *root = new Node();

    static void freeNode(Node *n) {
        if (!n) return;
        for (Node *c : n->next) freeNode(c);
        delete n;
    }

public:
    ~Trie() { freeNode(root); }

    void insert(const string &stem, int category) {
        Node *cur = root;
        for (char ch : stem) {
            int i = ch - 'a';
            if (i < 0 || i > 25) return;
            if (!cur->next[i]) cur->next[i] = new Node();
            cur = cur->next[i];
        }
        cur->category = category;
    }

    // does this word START with a stored stem? returns its category, or -1
    int findStem(const string &word) const {
        const Node *cur = root;
        for (char ch : word) {
            int i = ch - 'a';
            if (i < 0 || i > 25) break;
            cur = cur->next[i];
            if (!cur) break;
            if (cur->category >= 0) return cur->category;
        }
        return -1;
    }
};

// ---------- keyword engine: Trie + hash map + hash set ----------
class PriorityEngine {
    vector<CategoryDef> cats;
    unordered_map<string, int> phraseToCat; // DS 2: hash map, phrase -> category index
    unordered_set<string> urgentSet;        // DS 3: hash set of urgent words
    Trie trie;
    int maxWords = 1;

    static string normalize(const string &p) { // "Mid-Sem" -> "mid sem"
        vector<string> w = tokenize(p);
        string out;
        for (size_t i = 0; i < w.size(); i++) { if (i) out += ' '; out += w[i]; }
        return out;
    }
    void trackLength(const string &phrase) {
        int words = (int)count(phrase.begin(), phrase.end(), ' ') + 1;
        maxWords = max(maxWords, words);
    }

public:
    struct Result { string category; int score; string matched; bool urgent; };

    PriorityEngine() {
        cats = {
            {"Exam", 120,
             {"exam", "exams", "examination", "midsem", "mid sem", "mid semester", "endsem",
              "end sem", "end semester", "viva", "datesheet", "date sheet", "admit card", "hall ticket"}, {}},
            {"Class Rescheduling", 110,
             {"timetable", "time table", "class cancelled", "class canceled", "lecture cancelled",
              "lecture canceled", "class shifted", "venue change", "room change"},
             {"reschedul", "postpone", "prepone"}},
            {"Quiz", 100, {"quiz", "quizzes", "test", "unit test", "class test", "mcq"}, {}},
            {"Holiday", 90,
             {"holiday", "holidays", "vacation", "winter break", "summer break", "semester break",
              "no classes", "college closed", "university closed", "diwali", "holi", "eid",
              "christmas", "dussehra", "chhath"}, {}},
            {"Internship", 80,
             {"internship", "internships", "intern", "placement", "placements", "campus drive",
              "recruitment", "job fair", "hiring"}, {}},
            {"Enrollment", 70,
             {"enrollment", "enrolment", "registration", "admission", "course selection"},
             {"enroll", "register"}},
            {"Assignment", 60, {"assignment", "assignments", "submission", "submit", "lab file", "deadline"}, {}},
            {"Homework", 50,
             {"homework", "home work", "practice problems", "practice questions", "worksheet",
              "exercise", "exercises", "revision"}, {}},
            {"Event Participation", 40,
             {"event", "events", "fest", "competition", "hackathon", "workshop", "seminar",
              "webinar", "cultural", "sports day", "club", "participate", "participation", "contest"}, {}},
            {"Donation", 30,
             {"donation", "donations", "donate", "charity", "fundraiser", "fund raising"}, {"contribut"}},
            {"Bus Scheduling", 20, {"bus", "buses", "transport", "shuttle", "pickup", "bus timing"}, {}},
        };

        for (size_t ci = 0; ci < cats.size(); ci++) {
            for (auto &p : cats[ci].phrases) {
                string key = normalize(p);
                phraseToCat.emplace(key, (int)ci);
                trackLength(key);
            }
            for (auto &s : cats[ci].stems) trie.insert(s, (int)ci);
        }
        for (string u : {"urgent", "immediately", "today", "tomorrow", "asap", "important",
                         "tonight", "compulsory", "mandatory", "last date"}) {
            string key = normalize(u);
            urgentSet.insert(key);
            trackLength(key);
        }
    }

    Result classify(const string &title, const string &message) {
        vector<string> tokens = tokenize(title + " " + message);
        int best = -1;
        string matched;
        auto consider = [&](int c, const string &kw) {
            if (c >= 0 && (best < 0 || cats[c].score > cats[best].score)) { best = c; matched = kw; }
        };

        for (auto &t : tokens) consider(trie.findStem(t), t);      // 1) trie: word stems
        vector<string> grams = makeNgrams(tokens, maxWords);
        for (auto &g : grams) {                                    // 2) hash map: exact phrases
            auto it = phraseToCat.find(g);
            if (it != phraseToCat.end()) consider(it->second, g);
        }

        Result r;
        r.category = best < 0 ? "General" : cats[best].name;
        r.score = best < 0 ? 10 : cats[best].score;
        r.matched = matched;
        r.urgent = false;
        for (auto &g : grams)                                      // 3) hash set: urgent words
            if (urgentSet.count(g)) { r.urgent = true; break; }
        if (r.urgent) r.score += 5;
        return r;
    }
};

// ---------- storage + commands ----------
class NotificationManager {
    map<int, Notification> items;                  // DS 4: balanced tree (sorted by id)
    unordered_map<string, vector<int>> bySubject;  // DS 5: hash index, subject -> ids
    string file;
    PriorityEngine engine;

    static string toJson(const Notification &n) {
        return "{\"id\":" + to_string(n.id) + ",\"subjectId\":\"" + jsonEscape(n.subjectId) +
               "\",\"facultyId\":\"" + jsonEscape(n.facultyId) + "\",\"time\":" + to_string(n.time) +
               ",\"category\":\"" + jsonEscape(n.category) + "\",\"score\":" + to_string(n.score) +
               ",\"title\":\"" + jsonEscape(n.title) + "\",\"message\":\"" + jsonEscape(n.message) + "\"}";
    }

    static bool isBetter(const Notification &a, const Notification &b) {
        if (a.score != b.score) return a.score > b.score; // important first
        if (a.time != b.time) return a.time > b.time;     // then newest
        return a.id > b.id;
    }

    // DS 6: heap of size k. The WORST kept item sits on top, so when the heap grows
    // past k we pop it. Cost is O(m log k), no full sort needed.
    vector<const Notification *> pickTop(const vector<int> &ids, size_t k) {
        auto worstOnTop = [](const Notification *a, const Notification *b) {
            return isBetter(*a, *b);
        };
        priority_queue<const Notification *, vector<const Notification *>, decltype(worstOnTop)>
            heap(worstOnTop);
        for (int id : ids) {
            heap.push(&items.at(id));
            if (heap.size() > k) heap.pop();
        }
        vector<const Notification *> out;
        while (!heap.empty()) { out.push_back(heap.top()); heap.pop(); } // worst -> best
        reverse(out.begin(), out.end());                                  // best -> worst
        return out;
    }

public:
    NotificationManager(string f) : file(f) { load(); }

    void load() {
        ifstream in(file);
        string line;
        while (getline(in, line)) {
            stringstream ss(line);
            string id, t, sc;
            Notification n;
            getline(ss, id, '|');
            getline(ss, n.subjectId, '|');
            getline(ss, n.facultyId, '|');
            getline(ss, t, '|');
            getline(ss, n.category, '|');
            getline(ss, sc, '|');
            getline(ss, n.title, '|');
            getline(ss, n.message);
            try {
                n.id = stoi(id);
                n.time = stoll(t);
                n.score = stoi(sc);
            } catch (...) { continue; }
            items[n.id] = n;
            bySubject[n.subjectId].push_back(n.id);
        }
    }

    void save() {
        ofstream out(file);
        for (auto &kv : items) {
            const Notification &n = kv.second;
            out << n.id << '|' << n.subjectId << '|' << n.facultyId << '|' << n.time << '|'
                << n.category << '|' << n.score << '|' << n.title << '|' << n.message << '\n';
        }
    }

    void add(string sub, string fac, string title, string msg) {
        title = clean(title);
        msg = clean(msg);
        if (title.empty()) { cout << "{\"ok\":false,\"message\":\"Title is empty\"}"; return; }

        Notification n;
        n.id = items.empty() ? 1 : items.rbegin()->first + 1; // largest id + 1
        n.subjectId = clean(sub);
        n.facultyId = clean(fac);
        n.time = (long long)time(nullptr);
        n.title = title;
        n.message = msg;
        PriorityEngine::Result r = engine.classify(title, msg);
        n.category = r.category;
        n.score = r.score;

        items[n.id] = n;
        bySubject[n.subjectId].push_back(n.id);
        save();
        cout << "{\"ok\":true,\"id\":" << n.id << ",\"category\":\"" << n.category
             << "\",\"score\":" << n.score << ",\"matched\":\"" << jsonEscape(r.matched) << "\"}";
    }

    // student view: top N across the student's subjects, the rest only counted
    void printTop(int topN, const vector<string> &subjects) {
        unordered_set<string> uniq(subjects.begin(), subjects.end());
        vector<int> ids;
        for (auto &s : uniq) {
            auto it = bySubject.find(s);
            if (it != bySubject.end()) ids.insert(ids.end(), it->second.begin(), it->second.end());
        }
        size_t k = topN > 0 ? (size_t)topN : 0;
        vector<const Notification *> top = pickTop(ids, k);

        cout << "{\"shown\":[";
        for (size_t i = 0; i < top.size(); i++) {
            if (i) cout << ",";
            cout << toJson(*top[i]);
        }
        cout << "],\"hidden\":" << ids.size() - top.size() << ",\"total\":" << ids.size() << "}";
    }

    // faculty view: everything in one subject, in priority order
    void printSubject(const string &sub) {
        vector<int> ids;
        auto it = bySubject.find(sub);
        if (it != bySubject.end()) ids = it->second;
        vector<const Notification *> all = pickTop(ids, ids.size());

        cout << "{\"notifications\":[";
        for (size_t i = 0; i < all.size(); i++) {
            if (i) cout << ",";
            cout << toJson(*all[i]);
        }
        cout << "]}";
    }

    // only the faculty who posted it can delete it
    void remove(int id, const string &fac) {
        auto it = items.find(id);                         // O(log n)
        if (it == items.end()) { cout << "{\"ok\":false,\"message\":\"Not found\"}"; return; }
        if (it->second.facultyId != fac) {
            cout << "{\"ok\":false,\"message\":\"Not your notification\"}";
            return;
        }
        vector<int> &v = bySubject[it->second.subjectId];
        v.erase(std::remove(v.begin(), v.end(), id), v.end());
        items.erase(it);
        save();
        cout << "{\"ok\":true}";
    }

    // preview only, saves nothing
    void preview(const string &title, const string &msg) {
        PriorityEngine::Result r = engine.classify(title, msg);
        cout << "{\"category\":\"" << r.category << "\",\"score\":" << r.score
             << ",\"matched\":\"" << jsonEscape(r.matched) << "\",\"urgent\":"
             << (r.urgent ? "true" : "false") << "}";
    }
};

int main(int argc, char *argv[]) {
    if (argc < 2) { cout << "{\"error\":\"no command\"}"; return 1; }
    NotificationManager mgr("notifications.txt");
    string cmd = argv[1];

    if (cmd == "add" && argc >= 6) {             // add <subjectId> <facultyId> <title> <message>
        mgr.add(argv[2], argv[3], argv[4], argv[5]);
    } else if (cmd == "top" && argc >= 3) {      // top <N> <subjectId> <subjectId> ...
        vector<string> subs;
        for (int i = 3; i < argc; i++) subs.push_back(argv[i]);
        mgr.printTop(atoi(argv[2]), subs);
    } else if (cmd == "subject" && argc >= 3) {  // subject <subjectId>
        mgr.printSubject(argv[2]);
    } else if (cmd == "delete" && argc >= 4) {   // delete <id> <facultyId>
        mgr.remove(atoi(argv[2]), argv[3]);
    } else if (cmd == "classify" && argc >= 4) { // classify <title> <message>
        mgr.preview(argv[2], argv[3]);
    } else {
        cout << "{\"error\":\"bad command\"}";
        return 1;
    }
    return 0;
}